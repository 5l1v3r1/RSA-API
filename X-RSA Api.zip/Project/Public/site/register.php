<?php

include 'functionDB.php';
function secure($data)
{
    $data = htmlspecialchars($data,ENT_QUOTES);
    return $data;
}

function is_temp($email)
{
    $DomainName = ["gmail.com","outlook.com","yahoo.com","mail.ru"];
    $domain = explode("@",$email)[1];
    if(in_array($domain,$DomainName))
        return true;
    else
      return false;

}

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

  // Load Composer's autoloader
require 'vendor/autoload.php';

function Send_Mail($email , $token)
{ 
  $messege = "Hello Dear,<br>Thanks For Registration Your Token is : $token";
  $mail = new PHPMailer();
  $mail->SMTPDebug  = 0;
  $mail->isSMTP();
  $mail->Host = "smtp.gmail.com";
  $mail->SMTPAuth = true;
  $mail->SMTPSecure = "ssl";
  $mail->Port = 465;
  $mail->CharSet = "UTF-8";

  $mail->Username = "vector0x1@gmail.com";
  $mail->Password = "01005781242";
  $mail->setFrom("vector0x1@gmail.com", "X-RSA API");
  $mail->Subject = "X-RSA Token";
  $mail->msgHTML($messege);
  $mail->addAddress($email);
  if(!$mail->send())
    return false;
  else
    return true;
}




?>



<!DOCTYPE html>
<html>
<title>X-RSA API</title>
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background:url('https://www.w3schools.com/css/paper.gif');
  }
* {box-sizing: border-box;}

/* Full-width input fields */
input[type=text], input[type=password],input[type=email] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

/* Add a background color when the inputs get focus */
input[type=text]:focus, input[type=password]:focus ,input[type=email]:focus {
  background-color: #ddd;
  outline: none;
}

/* Set a style for all buttons */
button {
  background-color: #4CAF50;
  color: white;
  padding: 14px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

button:hover {
  opacity:1;
}

/* Extra styles for the cancel button */
.cancelbtn {
  padding: 14px 20px;
  background-color: #f44336;
}

/* Float cancel and signup buttons and add an equal width */
.cancelbtn, .signupbtn {
  float: left;
  width: 100%;
}

/* Add padding to container elements */
.container {
  padding: 1.5%;
}

/* The Modal (background) */
.modal {
  display: none; /* Hidden by default */
  position: fixed; /* Stay in place */
  z-index: 1; /* Sit on top */
  left: 0;
  top: 0;
  width: 100%; /* Full width */
  height: 100%; /* Full height */
  overflow: auto; /* Enable scroll if needed */
  background-color: #474e5d;
  padding-top: 50px;
}

/* Modal Content/Box */
.modal-content {
  background-color: #fefefe;
  margin: 5% auto 15% auto; /* 5% from the top, 15% from the bottom and centered */
  border: 1px solid #888;
  width: 80%; /* Could be more or less, depending on screen size */
}

/* Style the horizontal ruler */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}
 
/* The Close Button (x) */
.close {
  position: absolute;
  right: 35px;
  top: 15px;
  font-size: 40px;
  font-weight: bold;
  color: #f1f1f1;
}

.close:hover,
.close:focus {
  color: #f44336;
  cursor: pointer;
}

/* Clear floats */
.clearfix::after {
  content: "";
  clear: both;
  display: table;
}

/* Change styles for cancel button and signup button on extra small screens */
@media screen and (max-width: 300px) {
  .cancelbtn, .signupbtn {
     width: 100%;
  }
}
</style>
        <link rel="shortcut icon" href="https://3.top4top.net/p_128530q6o1.jpg">

<body>
  <form class="modal-content" action="" method="post">
    <div class="container">
      <h1>Sign Up To Get Your Token</h1>
      <p>Please fill in this form to create an account.</p>
      <hr>
      <label for="email"><b>Name</b></label>
      <input type="text" placeholder="Enter Name" name="Name" required>

      <label for="psw"><b>Email</b></label>
      <input type="email" placeholder="Enter Email" name="email" required>

      <label for="psw-repeat"><b>Password</b></label>
      <input type="password" placeholder="Enter Password" name="password" required>

<?php







if(!empty($_POST['Name']) && !empty($_POST['email']) && !empty($_POST['password']))
  {
    $name = secure($_POST['Name']);
    $password = secure($_POST['password']);
    $email = secure($_POST['email']);
    if(is_temp($email))
    {
      if(check_email($email))
          echo "<span style='color:red'>Email is exist</span>";
      else
      {
          $token = rand(99999999999999999,999999999999999999);
          $token .= rand(99999999999999999,999999999999999999);
          $token = password_hash($token,PASSWORD_DEFAULT);

          new_user($name,$password,$email,$token);
          if(Send_Mail($email,$token))
              echo "<span style='color:green'>Send Mail Successfully</span>";
          else
              echo "<span style='color:red'>Failed To Send Mail</span>";

      }
    }
    else 
      echo "<span style='color:red'>Email Must Be [gmail.com,outlook.com,yahoo.com,mail.ru]</span>";

}
?>

<p> <a href="get_token.php">Get Token</a> <a href="update_token.php">Update Token</a> <a href="forget.php">Reset Password</a></p>

      <div class="clearfix">
         <button type="submit" class="signupbtn">Sign Up</button>
      </div>
      
    </div>
  </form>
</body>
</html>

