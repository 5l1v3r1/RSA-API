<?php 


function get_Data($data)
{
    $new = array(
        'decimal' => $data,
        'Hex' => Tohex($data),
        'Ascii' => ToString($data),
    );
    return $new;
}



function ToString($code)
{
    $message = "";
    while(bccomp($code, '0') != 0)
    {
        $ascii    = bcmod($code, '256');
        $code     = bcdiv($code, '256', 0);
        $message .= chr($ascii);
    }

return strrev($message);
}

function Tohex($code)
{
    $message = "";
    while(bccomp($code, '0') != 0)
    {
        $ascii    = bcmod($code, '256');
        $code     = bcdiv($code, '256', 0);
        $message .= strrev(dechex($ascii));

    }

return strrev($message);
}


function zip($a1, $a2) {
    for($i = 0; $i < min(sizeof($a1), sizeof($a2)); $i++) {
      $out[$i] = [$a1[$i], $a2[$i]];
    }
    return $out;
  }


function chinese_remainder($n,$a)
{
    $sum = 0;
    $prod = 1;
    for($i = 0 ; $i < sizeof($n) ; $i++)
        if(isset($n[$i]))
            $prod = bcmul($prod,$n[$i]);
    
    $data = zip($n,$a);
    for($i=0;$i < sizeof($data); $i++)
    {
        $p = bcdiv($prod,$data[$i][0]);
        $sum = bcadd($sum,bcmul($data[$i][1],bcmul(mul_inv($p,$data[$i][0]),$p)));
    }
    return bcmod($sum,$prod);

}

function inv_pow($x,$n)
{
    $high = 1;
    while(bcpow($high,$n) < $x)
        $high = bcmul($high,"2");
    $low = bcdiv($high,"2");
    while($low < $high)
    {
        $mid = bcdiv(bcadd($low,$high),2);
        if($low < $mid && bcpow($mid,$n) < $x)
            $low = $mid;
        else if ($high > $mid && bcpow($mid,$n) > $x)
            $high = $mid;
        else
            return $mid;
    }
    return bcadd($mid,"1");
}

function mul_inv($a,$b)
{
    $b0 = $b;
    [$x0 , $x1] = [0,1];
    if($b == 1)
        return 1;
    while($a > 1)
    {
        $q = bcdiv($a,$b);
        $temp = $b ;
        $b = bcmod($a,$b);
        $a = $temp;

        $temp = $x0;
        $x0 = bcsub($x1,bcmul($q,$x0));
        $x1 = $temp;

    }
    if($x1 < 0)
        $x1 = bcadd($x1,$b0);
    return $x1;
}





function reduites_fraction_continue($a)
{
    $l = sizeof($a);
    $reduites=[];
    $h0 = 1;
    $h1 = 0;
    $k0 = 0;
    $k1 = 1;
    $count = 0;
    while($count < $l)
    {
        $h = bcadd(bcmul($a[$count],$h1),$h0);
        $h0 = $h1;
        $h1 = $h;
        $k = bcadd(bcmul($a[$count],$k1),$k0);
        $k0 = $k1;
        $k1 = $k;
        $reduites[] = [$k,$h];
        $count++;
    }
    return $reduites;
}
function division_euclidienne($a,$b)
{
    return [bcdiv($a,$b) , bcmod($a,$b)];
}
function fraction_continue($n,$d)
{
    $developpement = array();
    $a = $n ;
    $b = $d;
    while($b != 0)
    {
        [$q,$r] = division_euclidienne($a,$b);
        $developpement[] = $q;
        $a = $b;
        $b = $r;
    }
    return $developpement;
}

function factordb_prime($n)
{
    $content = file_get_contents("http://www.factordb.com/api?query=$n");
    $result  = (array)json_decode($content);
    $primeNumber = array();
    
    if(sizeof($result["factors"]) == 1)
        return json_encode("Can't Factorize N");
    for($i = 0 ; $i < sizeof($result) ; $i++)
        {   
            if(isset($result['factors'][$i][0]))
                $primeNumber[] = $result['factors'][$i][0];
        }
    
        return json_encode($primeNumber);
}


function neg_pow($a,$b,$n)
{
    assert($b < 0);
    assert(egcd($a , $n)[0] == 1);
    $res = modinv($a,$n);
    $res = powmod($res , bcmul($b,-1),$n);
    return $res;
}




function NRoot($num, $n) { 
    if ($n<1) return 0; // we want positive exponents 
    if ($num<=0) return 0; // we want positive numbers 
    if ($num<2) return 1; // n-th root of 1 or 2 give 1 

    // g is our guess number 
    $g=2; 

    // while (g^n < num) g=g*2 
    while (bccomp(bcpow($g,$n),$num)==-1) { 
        $g=bcmul($g,"2"); 
    } 
    // if (g^n==num) num is a power of 2, we're lucky, end of job 
    if (bccomp(bcpow($g,$n),$num)==0) { 
        return $g; 
    } 

    // if we're here num wasn't a power of 2 :( 
    $og=$g; // og means original guess and here is our upper bound 
    $g=bcdiv($g,"2"); // g is set to be our lower bound 
    $step=bcdiv(bcsub($og,$g),"2"); // step is the half of upper bound - lower bound 
    $g=bcadd($g,$step); // we start at lower bound + step , basically in the middle of our interval 

    // while step!=1 

    while (bccomp($step,"1")==1) { 
        $guess=bcpow($g,$n); 
        $step=bcdiv($step,"2"); 
        $comp=bccomp($guess,$num); // compare our guess with real number 
        if ($comp==-1) { // if guess is lower we add the new step 
            $g=bcadd($g,$step); 
        } else if ($comp==1) { // if guess is higher we sub the new step 
            $g=bcsub($g,$step); 
        } else { // if guess is exactly the num we're done, we return the value 
            return $g; 
        } 
    } 

    // whatever happened, g is the closest guess we can make so return it 
    return $g; 
}


function powmod($num, $pow, $mod)
    {
        if (function_exists('bcpowmod')) {
            // bcpowmod is only available under PHP5
            return bcpowmod($num, $pow, $mod);
        }
        // emulate bcpowmod
        $result = '1';
        do {
            if (!bccomp(bcmod($pow, '2'), '1')) {
                $result = bcmod(bcmul($result, $num), $mod);
            }
            $num = bcmod(bcpow($num, '2'), $mod);
            $pow = bcdiv($pow, '2');
        } while (bccomp($pow, '0'));
        return $result;
    }

function modinv($num, $mod)
    {
        $x = '1';
        $y = '0';
        $num1 = $mod;
        do {
            $tmp = bcmod($num, $num1);
            $q = bcdiv($num, $num1);
            $num = $num1;
            $num1 = $tmp;
            $tmp = bcsub($x, bcmul($y, $q));
            $x = $y;
            $y = $tmp;
        } while (bccomp($num1, '0'));
        if (bccomp($x, '0') < 0) {
            $x = bcadd($x, $mod);
        }
        return $x;
    }


function egcd($a, $b)
{
    if ($a == 0)
        return [$b, 0, 1];
    else
    {
        $data = egcd(bcmod($b,$a), $a);
        $g = $data[0];
        $y = $data[1];
        $x = $data[2];
        return [$g, (bcsub($x ,bcdiv($b , $a) * $y)), $y];
    }
}

function decrypt($c, $d, $n) {
    $coded   = explode('.', $c);
    $message = '';
    $max     = count($coded);
    for($i=0; $i<$max; $i++){
        $code = bcpowmod($coded[$i], $d, $n);
    $newcode = $code;
        while(bccomp($code, '0') != 0){
            $ascii    = bcmod($code, '256');
            $code     = bcdiv($code, '256', 0);
            $message .= chr($ascii);
        }
    }
    return [$newcode,strrev($message)];
}





?>
