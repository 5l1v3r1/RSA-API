$("html").niceScroll();

$("header").height($(window).height());

$(window).on("resize" , function(){
    $("header").height($(window).height());
});

$(".goBottom").on("click" , function(){
    $(window).scrollTop($(window).height())
});

$("table tr:even").css("background-color" , "#f1f1f1")

$("table tr:even:eq(4)").css("background-color" , "#fff")