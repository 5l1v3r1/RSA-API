<!DOCTYPE html>
<html>
    <head>
        <title>X-RSA API</title>
        <link rel="shortcut icon" href="https://3.top4top.net/p_128530q6o1.jpg">
        <link rel="stylesheet" href="css/bootstrap.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <link rel="stylesheet" href="css/hover.css">
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>

        <header>
            <div class="container col-xs-12">
                <div class="rsa">
                    <h1>What's X-RSA API ?</h1>
                    <p class="lead">- it's a API Tool Which contains a many of attack types in RSA , and it's still under development and adding other Attacks.</p>
                    <p class="lead">- Download Python Version From <a class="grow" href="https://github.com/X-Vector/X-RSA">Github</a></p>
                </div>
            </div>
            <div class="goBottom sink"><i class="fa fa-angle-double-down"></i></div>
        </header>

        <section>
            <div class="container">
                <div class="row">
                    <div class="">

                        <div class="step1">
                            <h2>How Can I Use X-RSA API ?</h2>
                        </div>
                        
                        <div class="step2">
                            <p class="lead">1 -  <a class="grow" href="register.php" target="_blank">Sign up</a> To Get Your Token</p>
                            <p class="lead">2 - You Can Use Any Avaliable Attack With API</p>
                            <table border="1px">
                                <tr>
                                    <th>Attack Type</th>
                                    <th>Site</th>
                                </tr>
                                <tr>
                                    <td>Comman Modulus [c1,c2,e1,e2,n]</td>
                                    <td>127.0.0.1/New/Project/Public/RSA/common_modulus/email={email}&token={Token}&n={n}&e1={e1}&c1={c1}&e2={e2}&c2={c2}</td>
                                </tr>

                                <tr>
                                    <td>Comman Exponante [c1,c2,n1,n2,e]</td>
                                    <td>127.0.0.1/New/Project/Public/RSA/common_exponent/email={email}&token={Token}&n1={n1}&n2={n2}&c1={c1}&c2={c2}&e={e}</td>      </td>
                                </tr>

                                <tr>
                                    <td>Chienese Reminder Theorm [c,p,q,dp,dq]</td>
                                    <td>127.0.0.1/New/Project/Public/RSA/CRT/email={email}&token={Token}&c={c}&p={p}&q={q}&dp={dp}&dq={dq}</td>
                                </tr>

                                <tr>
                                    <td>Very Small exponant [c,e=3]</td>
                                    <td>127.0.0.1/New/Project/Public/RSA/small_exponant/email={email}&token={Token}&c={c}&e={e}</td>
                                </tr>

                                <tr>
                                    <td>Multiprimes Attack [primes,c,e]</td>
                                    <td>127.0.0.1/New/Project/Public/RSA/multiprime/email={email}&token={Token}&primes={p1,p2,p3...}&c={c}&e={e}</td>
                                </tr>

                                <tr>
                                    <td>Hasted Attack [{n1,n2,...},{c1,c2,...}]</td>
                                    <td>127.0.0.1/New/Project/Public/RSA/Hasted/email={email}&token={Token}&n={n1,n2,n3...}&c={c1,c2,c3..}</td>
                                </tr>

                                <tr>
                                    <td>RSA Signature [signature,n,e]</td>
                                    <td>127.0.0.1/New/Project/Public/RSA/signuatre/email={email}&token={token}&n={n}&sign={sign}&e={e}</td>
                                </tr>

                                <tr>
                                    <td rowspan=2>Winner Attack [c,n,e]</td>
                                    <td>127.0.0.1/New/Project/Public/RSA/winner/email={email}&token={Token}&n={n}&e={e} <span style="color:green"> // Return with Private Key</span></td>
                                </tr>

                                <tr>
                                    <td>127.0.0.1/New/Project/Public/RSA/winner/email={email}&token={Token}&n={n}&e={e}&c={c}</td>
                                </tr>

                                <tr style="background-color:#f1f1f1">
                                    <td rowspan=2>Cyclic Attack [c,n,e,k] </td>
                                    <td>127.0.0.1/New/Project/Public/RSA/Cycle_Attack/email={email}&token={Token}&n={n}&c={c}&e={e} <span style="color:green"> // k = 9999</span></td>
                                </tr>

                                <tr>
                                    <td>127.0.0.1/New/Project/Public/RSA/Cycle_Attack/email={email}&token={Token}&n={n}&c={c}&e={e}&k={k}</td>
                                </tr>

                                <tr>
                                    <td>Attack [c,d,n] </td>
                                    <td>127.0.0.1/New/Project/Public/RSA/rsa1/email={email}&token={Token}&n={n}&c={c}&d={d}</td>
                                </tr>

                                <tr>
                                    <td>Attack [c,p,q,e] </td>
                                    <td>127.0.0.1/New/Project/Public/RSA/rsa2/email={email}&token={Token}&c={c}&p={p}&q={q}&e={e}</td>
                                </tr>

                                <tr>
                                    <td>Attack [c,n,p,e]</td>
                                    <td>127.0.0.1/New/Project/Public/RSA/rsa3/email={email}&token={Token}&n={n}&c={c}&p={p}&e={e}</td>
                                </tr>

                                <tr>
                                    <td>Attack [c,n,e] {Factordb}</td>
                                    <td>127.0.0.1/New/Project/Public/RSA/rsa4/email={email}&token={Token}&n={n}&c={c}&e={e}</td>
                                </tr>
                                <tr>
                                    <td>Attack [c,n,dp,e] </td>
                                    <td>127.0.0.1/New/Project/Public/RSA/rsa5/email={email}&token={Token}&n={n}&c={c}&dp={dp}&e={e}</td>
                                </tr>

                            </table>
                        </div>

                        <div class="step3">
                            <p class="lead">3 - Data is Returned by Encoding with Json to Facilitate Using Our Application in your Projects</p>
                            <div>
                            
                        <div class="step3">
                            <p class="lead">4 - Simple [PHP , Python] Code To Use X-RSA API</p>
                            <div>
                                
                                <span style="cursor:pointer" onclick="PHP()" >PHP Code</span>
                                <span style="cursor:pointer" onclick="python()" >Python Code</span>
                                <div id='data'>
                                <div><div class="code"><ol><li>&nbsp;&nbsp;&lt;?php</li><li class="indent">$url = "http://127.0.0.1/New/Project/Public/RSA/small_exponant/email={email}&token={token}&c={c}&e={e}";</li><li class="indent">$content = file_get_contents($url);</li><li class="indent">$result  = (array)json_decode($content);</li><li class="indent">echo "Decimal : ",$result["decimal"],"&lt;br&gt;";</li><li class="indent">echo "Hex : ",$result["Hex"],"&lt;br&gt;";</li><li class="indent">echo "Ascii : ",$result["Ascii"],"&lt;br&gt;";</li><li>&nbsp;&nbsp;?&gt;</li></ol></div></div>
                                </div>
                            <div>
                            </div>
                                
                               
                            </div>


                        </div> 
                    </div>
                </div>
            </div>
        </section>

        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="social_media">
                            <a href="https://www.facebook.com/X.Vector1" target="_blank"><i class="fa fa-facebook fa-2x"></i></a>
                            <a href="https://github.com/X-Vector/" target="_blank"><i class="fa fa-github fa-2x"></i></a>
                            <a href="https://twitter.com/@XVector11" target="_blank"><i class="fa fa-twitter fa-2x"></i></a>
                            <a href="mailto:algazarbas@gmail.com" target="_blank"><i class="fa fa-envelope fa-2x"></i></a>
                            <a href="https://www.linkedin.com/in/x-vector/" target="_blank"><i class="fa fa-linkedin fa-2x"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <script>
            function PHP()
            {
                document.getElementById('data').innerHTML = '<div><div class="code"><ol><li>&nbsp;&nbsp;&lt;?php</li><li class="indent">$url = "http://127.0.0.1/New/Project/Public/RSA/small_exponant/email={email}&token={token}&c={c}&e={e}";</li><li class="indent">$content = file_get_contents($url);</li><li class="indent">$result  = (array)json_decode($content);</li><li class="indent">echo "Decimal : ",$result["decimal"],"&lt;br&gt;";</li><li class="indent">echo "Hex : ",$result["Hex"],"&lt;br&gt;";</li><li class="indent">echo "Ascii : ",$result["Ascii"],"&lt;br&gt;";</li><li>&nbsp;&nbsp;?&gt;</li></ol></div></div>'
            }
            function python()
            {
                document.getElementById('data').innerHTML = '<div class="code"><ol><li class="indent">import json , requests</li><li class="indent">url = "http://127.0.0.1/New/Project/Public/RSA/small_exponant/email={email}&token={token}&c={c}&e={e}"</li><li class="indent">r = requests.get(url)</li><li class="indent">data = json.loads(r.text)</li><li class="indent">print("Decimal :",data["decimal"])</li><li class="indent">print("Hex :",data["Hex"])</li><li class="indent">print("Ascii :",data["Ascii"])</li></ol></div>'
            }
        </script>

        <script src="js/jquery-1.11.1.min.js"></script>
        <script src="js/bootstrap.min.js"></script>
        <script src="js/jquery.nicescroll.min.js"></script>
        <script src="js/plugins.js"></script>
    </body>
</html>