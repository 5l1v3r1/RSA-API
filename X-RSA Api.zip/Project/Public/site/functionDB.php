<?php 



function Update_token($email,$password,$token)
{
    $con = new PDO("mysql:host=localhost;dbname=crypto_rsa","root","") or die("Unable To Connect");
    $sql = "UPDATE users SET token=? WHERE email = ? AND password = ?";
    $stmt = $con -> prepare($sql);
    $stmt -> execute(array($token,$email,$password)) or die("[-] Can't Add User");
    while($row = $stmt -> fetch())
    {
        return $row[0];
    }

}



function Update_password($email,$password)
{
    $con = new PDO("mysql:host=localhost;dbname=crypto_rsa","root","") or die("Unable To Connect");
    $sql = "UPDATE users SET password=? WHERE email = ?";
    $stmt = $con -> prepare($sql);
    $stmt -> execute(array($password,$email)) or die("[-] Can't Update Password");
    while($row = $stmt -> fetch())
    {
        return $row[0];
    }

}




function Get_token($email,$password)
{
    $con = new PDO("mysql:host=localhost;dbname=crypto_rsa","root","") or die("Unable To Connect");
    $sql = "SELECT token FROM users WHERE email=? AND password=?";
    $stmt = $con -> prepare($sql);
    $stmt -> execute(array($email,$password)) or die("[-] Can't Add User");
    while($row = $stmt -> fetch())
    {
        return $row[0];
    }

}

function new_user($name,$password,$email,$token)
{
    $con = new PDO("mysql:host=localhost;dbname=crypto_rsa","root","") or die("Unable To Connect");
    $sql = "INSERT INTO users VALUES (?,?,?,?)";
    $stmt = $con -> prepare($sql);
    $stmt -> execute(array($name,$email,$password,$token)) or die("[-] Can't Add User");
}


function check_email($email)
{
    $con = new PDO("mysql:host=localhost;dbname=crypto_rsa","root","") or die("Unable To Connect");
    $sql = "SELECT COUNT(*) FROM users WHERE email=?";
    $stmt = $con -> prepare($sql);
    $stmt -> execute(array($email)) or die("[-] Something Wrong");
    while($row = $stmt -> fetch())
    {
        if($row[0] > 0)
            return true;
        else
            return false;
    }
}


function check_email_token($email,$token)
{
    $con = new PDO("mysql:host=localhost;dbname=crypto_rsa","root","") or die("Unable To Connect");
    $sql = "SELECT COUNT(*) FROM users WHERE email=? AND token = ?";
    $stmt = $con -> prepare($sql);
    $stmt -> execute(array($email,$token)) or die("[-] Something Wrong");
    while($row = $stmt -> fetch())
    {
        if($row[0] > 0)
            return true;
        else
            return false;
    }
}




?>